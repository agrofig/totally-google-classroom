

# 30 Days Challenge | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2219a12658-9f5b-4d45-a4a5-71f53cfbf8c2%22%2C%22flow%22%3Atrue%7D%7D)
Weight loss challenge in thirty days with core exercises.

# Prompt

```
Shedding 10kgs in 30 days with moderate diet plan and immunity building excercises.
```





