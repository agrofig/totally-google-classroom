

# AI Optimized Diet Plan | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%226bf2355c-fc86-4b39-807a-eeb83afa05cf%22%2C%22flow%22%3Atrue%7D%7D)
Embrace transformation through the power of AI. Personalized meal plans and grocery lists tailored to meet your health and fitness goals. Great for people people who don't know where to start, but know where they want to be.

# Prompt

```
create me a one week meal plan based on the following information, and with exact measurements for each item, please. #[calories] calories, #[protein] grams of protein, #[carbs] grams of carbs, #[fats] grams of fat, excluding #[foods to exclude/ dietary restrictions], #[type of diet] diet, under #[budget]
```





