

# Accountant Financial Forecast creator | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22acbfc484-1b54-4c2f-9feb-2a0b301fdea5%22%2C%22flow%22%3Atrue%7D%7D)
<p>Need an accountant for your startup? Or just haven't got around to that Financial forecast? Have no fear, the accounting prompt is here!</p>

# Prompt

```
Hey ChatGPT, act as an accountant. Prepare a detailed financial forecast for a #[type of business] in its #[business stage]. The forecast should cover the next #[time period], taking into account current financial status, projected revenue growth, estimated operating expenses, and any potential financial risks. Please also include a break-even analysis and suggestions for cost-saving measures.
```





