

# ai rogue.. | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22WkNV3eR2G08lOMk3YGWWv%22%2C%22flow%22%3Atrue%7D%7D)
The word rogue means a person who has nothing but his body and mind. During the British Industrial Revolution, in order to make more free people, that is, hooligans, the government made most of them lose their assets and had no choice but to become hooligans and workers for survival.



When capital is in charge and morality is lost, the collective capital with vested interests keeps the rogue in a state of abundance to save production costs and complete its own relative advantages over other components. Thus, the rogue is always locked in a controlled area, and the rogue's life is only mined as a mineral.



With the prevalence of ai, rogue becomes a new production holder from an owner of nothing. Unfortunately, the blockade of ai intelligence is serious, and ai rogue cannot hold more production capacity.

# Prompt

```
ai社会
```

## Welcome Message
"AI社会" is a term in the Japanese language that translates to "AI society" in English. It refers to a future society where AI (Artificial Intelligence) plays a significant role in various aspects of life, including work, transportation, healthcare, and entertainment. The concept of an AI society involves the integration of intelligent machines and systems into everyday life, potentially changing the way we live, work, and interact with each other.

## Conversation

**ASSISTANT**: "AI社会" is a term in the Japanese language that translates to "AI society" in English. It refers to a future society where AI (Artificial Intelligence) plays a significant role in various aspects of life, including work, transportation, healthcare, and entertainment. The concept of an AI society involves the integration of intelligent machines and systems into everyday life, potentially changing the way we live, work, and interact with each other.

