

# Adult Coloring Book Animal - Midjourney | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2202ce0704-c107-4795-93ec-2abfc0014e95%22%2C%22flow%22%3Atrue%7D%7D)
Adult Coloring Book (Stress Relieving Creative Fun Drawings to Calm Down, Reduce Anxiety & Relax.

# Prompt

```
Coloring page for adults, bold lines, dark lines, mandala body, mandala #[Theme Animal] face, mandala face, #[Animal Breed], white background, clean line art, fine line art, black and white --ar 2:3
```





