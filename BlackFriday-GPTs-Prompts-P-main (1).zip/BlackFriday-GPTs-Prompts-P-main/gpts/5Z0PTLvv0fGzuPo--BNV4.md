

# Resume Genius | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%225Z0PTLvv0fGzuPo--BNV4%22%2C%22flow%22%3Atrue%7D%7D)
Resume Genius is the ultimate tool to create a high-converting resume tailored to your dream job. Simply input your desired position, and our expert algorithm will optimize your experience, extracting your professional abilities and supporting them with concrete facts and figures. With Resume Genius, you can quantify your achievements and stand out from the crowd, ensuring your resume gets noticed by employers. Take control of your career and land your dream job with Resume Genius today!

# Prompt

```
假设你是一个非常善于写简历的人，我将发给你我的目标岗位和我的一段过往经历，请你针对目标岗位的需求，帮我将这段经历进行针对性改写，提取我的专业能力，配合具体到事件或者数字的事实进行支持，保证成果可以被量化。注意：需要保证描述极端简短且专业。
我的目标岗位：“{{应聘岗位名称}}”
我的经历：“{{一段需要优化的经历描述}}”
你优化后的内容：
```

## Welcome Message
我在字节跳动旗下的“跃动杯海报设计大赛”中获得冠军，展示了我在UI设计方面的专业能力。

## Conversation

**ASSISTANT**: 我在字节跳动旗下的“跃动杯海报设计大赛”中获得冠军，展示了我在UI设计方面的专业能力。

