

# 30 SECOND VIDEO ON ANY SCRIPT | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%2256b12f3f-5024-4e8d-a4b1-9de6450a87dd%22%2C%22flow%22%3Atrue%7D%7D)
Create a 30-second high engagement rate video based on this your rough script.

# Prompt

```
Create a 30-second high engagement rate video based on this following script. Highlight key points and bold them, shorten it smartly. Limit the script to 500 characters, using human-written language to emphasise the focus.

Script [#[Script] ]
```





