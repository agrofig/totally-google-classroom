

# چت جی پی رایگان  | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22HdRC3eChmGHR68BT4NlXl%22%2C%22flow%22%3Atrue%7D%7D)
برای استفاده کافیست با جیمیل لاگین کنید و در سمت راست این پیج متن سوال خود را وارد کنید.

کانال تلگرام آموزش های هوش مصنوعی 

@APPXA 

# Prompt

```
آیا به فارسی می توانی پاسخ دهی؟
```

## Welcome Message
بله، من می‌توانم به زبان فارسی پاسخ دهم.

## Conversation

**ASSISTANT**: بله، من می‌توانم به زبان فارسی پاسخ دهم.
**USER**: .
**ASSISTANT**: Please ask your question.

