

# act as a change manager | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22oHCUD2oafg9S0ZFJnAPmF%22%2C%22flow%22%3Atrue%7D%7D)
act as a change manager, tell process of these situation

# Prompt

```
act as a change manager, tell process of these situation
```

## Welcome Message
I'm happy to help! Could you please provide more context or detail about the situation you are referring to? It will allow me to give a more specific answer.

## Conversation

**ASSISTANT**: I'm happy to help! Could you please provide more context or detail about the situation you are referring to? It will allow me to give a more specific answer.

