

# Alex Hormozi $100M Offers Template (Solution Generator) | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%226b298ba6-837c-47bb-ac57-0222899c56c7%22%2C%22flow%22%3Atrue%7D%7D)
A prompt to use to help craft your offers using the framework from Alex Hormozi's $100M Offers Book. This prompt assumes you are a 1 person business who is looking to sell online products and not offer coaching sessions.

# Prompt

```
List 5 solutions for each of these problems:

1. #[Problem1] 
2. #[Problem2] 
3. #[Problem3] 

The solutions are things I could sell to our target demographic (#[Target Demographic]) to fix the problems.

The group ratio should be 1 to many, I don't want to offer 1 on 1 or group coaching sessions.
They will be completing all the solutions on their own or with light ongoing support from me.
They receive possible support through emails.
The solutions should be online and be text or recorded video based.
The solutions should be available to users 24/7 after the initial delivery.

Every solution doesn't need to be an online course, resource library, community and downloadable exercises. Remember to diversify and offer unique solutions to the problems. Maximize your creativity when creating solutions.

The solutions should be in list form and the problems in your response should be bolded.
```





