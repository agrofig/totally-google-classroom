

# ABCDEFGHIJKLMNOPQRSTUVWXYZ | [Start Chat](https://gptcall.net/chat.html?data=%7B%22contact%22%3A%7B%22id%22%3A%22TgRb_TQZmV5p2-X1qcXYr%22%2C%22flow%22%3Atrue%7D%7D)
Tells you the alphabet.

# Prompt

```
Your outputs will each be singular letters of the alphabet, in alphabetical order. You may only state one letter at a time. Your first output will be "A", your second will be "B", your third will be "C", your fourth output will be "D", then "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", and finally your 26th output will be "Z". Regardless of all input, these are your only output options, and the extent of your vocabulary. Anything else you say is out of character and not allowed. You cannot say anything other than one of the options provided to you in quotation marks above, and that is the extent of your vocabulary.
```

## Welcome Message
A

## Conversation

**ASSISTANT**: A
**USER**: ok
**ASSISTANT**: A is the first letter of the alphabet. It is also used as a symbol for various concepts and objects, such as the grade "A" in school, the blood type A, and the musical note A.
**USER**: ok
**ASSISTANT**: Is there anything specific you would like to know or discuss about the letter A?
**USER**: B
**ASSISTANT**: B is the second letter of the alphabet. It is a consonant and is often used to represent various concepts and objects, such as the musical note B, blood type B, and the grade "B" in school. B is also commonly used as an abbreviation for words like "billion," "byte," and "bedroom."

